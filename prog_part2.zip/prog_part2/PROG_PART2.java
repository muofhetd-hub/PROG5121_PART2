/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.st10538230.prog_part2;

/**
 *
 * @author Admin
 */
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;

public class PROG_PART2 {

// Tracking collections
    static ArrayList<String> idCollection = new ArrayList<>();
    static ArrayList<String> hashCollection = new ArrayList<>();
    static ArrayList<String> phoneCollection = new ArrayList<>();
    static ArrayList<String> textCollection = new ArrayList<>();
    static ArrayList<String> statusCollection = new ArrayList<>();
    
    static Scanner userInput = new Scanner(System.in);
    
    // Login credentials
    static String userName = "";
    static String passCode = "";
    static boolean accountCreated = false;
    
    // Counters
    static int sendCount = 0;
    static int saveCount = 0;
    static int deleteCount = 0;
    
    static final String STORAGE_FILE = "chat_records.json";
    
    public static void main(String[] args) {
        printWelcome();
        
        boolean loggedIn = false;
        
        while (!loggedIn) {
            displayEntryMenu();
            String selection = userInput.nextLine().trim();
            
            if (selection.equals("1")) {
                createAccount();
            } else if (selection.equals("2")) {
                if (accountCreated) {
                    loggedIn = verifyLogin();
                } else {
                    System.out.println(">>> No account exists! Please register first.\n");
                }
            } else if (selection.equals("3")) {
                System.out.println(">>> Application closed. Have a nice day!\n");
                System.exit(0);
            } else {
                System.out.println(">>> Invalid choice! Try again.\n");
            }
        }
        
        launchMessenger();
    }
    
    static void printWelcome() {
        System.out.println("\n+-----------------------------------+");
        System.out.println("|                                   |");
        System.out.println("|         QUICK MESSAGE HUB         |");
        System.out.println("|         THENDO DAVID MUOFHE               |");
        System.out.println("|         ST10538230                          |");
        System.out.println("+-----------------------------------+\n");
    }
    
    static void displayEntryMenu() {
        System.out.println("=== MAIN MENU ===");
        System.out.println("|1| Register New Account");
        System.out.println("|2| Sign In");
        System.out.println("|3| Exit Program");
        System.out.print("\nYour pick: ");
    }
    
    static void createAccount() {
        System.out.println("\n>>> ACCOUNT REGISTRATION <<<");
        System.out.print("Enter username: ");
        userName = userInput.nextLine().trim();
        System.out.print("Enter password: ");
        passCode = userInput.nextLine().trim();
        accountCreated = true;
        System.out.println(">>> Account successfully created!\n");
    }
    
    static boolean verifyLogin() {
        System.out.println("\n>>> LOGIN <<<");
        System.out.print("Username: ");
        String enteredName = userInput.nextLine().trim();
        System.out.print("Password: ");
        String enteredPass = userInput.nextLine().trim();
        
        if (enteredName.equals(userName) && enteredPass.equals(passCode)) {
            System.out.println(">>> Access granted!\n");
            return true;
        } else {
            System.out.println(">>> Access denied! Wrong credentials.\n");
            return false;
        }
    }
    
    static void launchMessenger() {
        System.out.println("Welcome to Quick Message Hub!\n");
        
        int msgQuantity = 0;
        while (msgQuantity <= 0) {
            System.out.print("How many messages to compose? ");
            try {
                msgQuantity = Integer.parseInt(userInput.nextLine().trim());
                if (msgQuantity <= 0) {
                    System.out.println(">>> Please enter a positive number.\n");
                }
            } catch (NumberFormatException e) {
                System.out.println(">>> Invalid number format!\n");
            }
        }
        
        boolean programActive = true;
        
        while (programActive) {
            showActionMenu();
            String cmd = userInput.nextLine().trim();
            
            if (cmd.equals("1")) {
                handleMessages(msgQuantity);
                presentSummary();
                System.out.print("\nPress ENTER to continue or type 'exit' to quit: ");
                String response = userInput.nextLine().trim();
                if (response.equalsIgnoreCase("exit")) {
                    programActive = false;
                }
            } else if (cmd.equals("2")) {
                System.out.println(">>> Coming Soon! Check back in Part 3.\n");
            } else if (cmd.equals("3")) {
                System.out.println(">>> Shutting down. Goodbye!\n");
                programActive = false;
            } else {
                System.out.println(">>> Invalid option! Choose 1, 2, or 3.\n");
            }
        }
        
        userInput.close();
    }
    
    static void showActionMenu() {
        System.out.println("\n=== MESSENGER MENU ===");
        System.out.println("|1| Write & Send Messages");
        System.out.println("|2| View Sent Items");
        System.out.println("|3| Exit Messenger");
        System.out.print("\nSelect option: ");
    }
    
    static void handleMessages(int totalMsgs) {
        for (int round = 0; round < totalMsgs; round++) {
            System.out.println("\n--- MESSAGE #" + (round + 1) + " of " + totalMsgs + " ---");
            
            String phoneNumber = capturePhone();
            String messageBody = captureMessage();
            
            MessageItem item = new MessageItem(round + 1, phoneNumber, messageBody);
            
            System.out.println("\n[PREVIEW SCREEN]");
            System.out.println(item.showPreview());
            
            String decision = askUserAction();
            System.out.println(decision);
            
            if (decision.equals(">>> Message transmitted!")) {
                idCollection.add(item.getMsgId());
                hashCollection.add(item.getSecurityHash());
                phoneCollection.add(item.getDestPhone());
                textCollection.add(item.getMsgBody());
                statusCollection.add("SENT");
                sendCount++;
            } else if (decision.equals(">>> Message archived to storage!")) {
                idCollection.add(item.getMsgId());
                hashCollection.add(item.getSecurityHash());
                phoneCollection.add(item.getDestPhone());
                textCollection.add(item.getMsgBody());
                statusCollection.add("ARCHIVED");
                saveCount++;
                item.writeToFile();
            } else if (decision.equals(">>> Message thrown away.")) {
                deleteCount++;
            }
        }
    }
    
    static String capturePhone() {
        String phoneNum = "";
        boolean validFlag = false;
        
        while (!validFlag) {
            System.out.print("Recipient's SA number (0712345678 or +27712345678): ");
            phoneNum = userInput.nextLine().trim();
            String cleaned = phoneNum.replaceAll("\\s|-", "");
            
            if (cleaned.matches("^0[678][0-9]{8}$") || cleaned.matches("^\\+27[678][0-9]{8}$")) {
                validFlag = true;
            } else {
                System.out.println(">>> Invalid SA format! Try again.\n");
            }
        }
        return phoneNum;
    }
    
    static String captureMessage() {
        String msgText = "";
        boolean good = false;
        
        while (!good) {
            System.out.print("Your message (max 250 chars): ");
            msgText = userInput.nextLine().trim();
            
            if (msgText.length() <= 250) {
                good = true;
            } else {
                int excess = msgText.length() - 250;
                System.out.println(">>> Too long by " + excess + " characters! Shorten it.\n");
            }
        }
        return msgText;
    }
    
    static String askUserAction() {
        System.out.println("\n--- OPTIONS ---");
        System.out.println("[1] Send Now");
        System.out.println("[2] Discard");
        System.out.println("[3] Save to Storage");
        System.out.print("Choose (1-3): ");
        
        String option = userInput.nextLine().trim();
        
        if (option.equals("1")) {
            return ">>> Message transmitted!";
        } else if (option.equals("2")) {
            return ">>> Message thrown away.";
        } else if (option.equals("3")) {
            return ">>> Message archived to storage!";
        } else {
            System.out.println(">>> Invalid. Default: Discarded.");
            return ">>> Message thrown away.";
        }
    }
    
    static void presentSummary() {
        System.out.println("\n╔════════════════════════════════════════╗");
        System.out.println("║           FINAL REPORT                 ║");
        System.out.println("╠════════════════════════════════════════╣");
        System.out.println("║ Transmitted:   " + padNumber(sendCount) + "                          ║");
        System.out.println("║ Archived:      " + padNumber(saveCount) + "                          ║");
        System.out.println("║ Discarded:     " + padNumber(deleteCount) + "                          ║");
        System.out.println("║ Total Created: " + padNumber(sendCount + saveCount + deleteCount) + "                          ║");
        System.out.println("╚════════════════════════════════════════╝");
        
        if (!idCollection.isEmpty()) {
            System.out.println("\n>>> STORED MESSAGES LOG <<<");
            for (int i = 0; i < idCollection.size(); i++) {
                System.out.println("\n[" + (i+1) + "]");
                System.out.println("   ID: " + idCollection.get(i));
                System.out.println("   Hash: " + hashCollection.get(i));
                System.out.println("   Recipient: " + phoneCollection.get(i));
                System.out.println("   Content: " + textCollection.get(i));
                System.out.println("   State: " + statusCollection.get(i));
            }
        }
    }
    
    static String padNumber(int val) {
        if (val < 10) {
            return " " + val;
        }
        return String.valueOf(val);
    }
    
    // ========== INNER MESSAGE CLASS ==========
    
    static class MessageItem {
        private String uniqueId;
        private int sequenceNum;
        private String destination;
        private String content;
        private String encodedHash;
        
        public MessageItem(int seq, String phone, String msg) {
            this.sequenceNum = seq;
            this.destination = phone;
            this.content = msg;
            this.uniqueId = generateUniqueId();
            this.encodedHash = computeEncodedHash();
        }
        
        private String generateUniqueId() {
            Random r = new Random();
            long num = 1000000000L + (long)(r.nextDouble() * 9000000000L);
            String result = String.valueOf(num);
            if (result.length() > 10) {
                result = result.substring(0, 10);
            }
            return result;
        }
        
        private String computeEncodedHash() {
            String prefix = this.uniqueId.substring(0, 2);
            String[] words = this.content.trim().split("\\W+");
            String firstWord = words.length > 0 ? words[0].toUpperCase() : "";
            String lastWord = words.length > 1 ? words[words.length-1].toUpperCase() : firstWord;
            
            firstWord = firstWord.replaceAll("[^A-Z]", "");
            lastWord = lastWord.replaceAll("[^A-Z]", "");
            
            if (firstWord.length() > 4) firstWord = firstWord.substring(0, 4);
            if (lastWord.length() > 4) lastWord = lastWord.substring(0, 4);
            
            return prefix + ":" + this.sequenceNum + ":" + firstWord + lastWord;
        }
        
        public String showPreview() {
            return "ID: " + this.uniqueId + "\n" +
                   "Hash: " + this.encodedHash + "\n" +
                   "To: " + this.destination + "\n" +
                   "Message: " + this.content;
        }
        
        public void writeToFile() {
            try {
                File f = new File(STORAGE_FILE);
                
                try (FileWriter fw = new FileWriter(STORAGE_FILE, true)) {
                    fw.write("{\n");
                    fw.write("  \"msg_id\": \"" + this.uniqueId + "\",\n");
                    fw.write("  \"hash_val\": \"" + this.encodedHash + "\",\n");
                    fw.write("  \"phone\": \"" + this.destination + "\",\n");
                    fw.write("  \"text\": \"" + this.content.replace("\"", "\\\"") + "\",\n");
                    fw.write("  \"saved_at\": \"" + System.currentTimeMillis() + "\"\n");
                    fw.write("}\n");
                }
                
                System.out.println(">>> Saved to: " + f.getAbsolutePath());
                
            } catch (IOException e) {
                System.out.println(">>> Write error: " + e.getMessage());
            }
        }
        
        public String getMsgId() { return uniqueId; }
        public String getSecurityHash() { return encodedHash; }
        public String getDestPhone() { return destination; }
        public String getMsgBody() { return content; }
    }
}